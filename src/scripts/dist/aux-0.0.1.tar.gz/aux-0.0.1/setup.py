from setuptools import setup, find_packages

setup(
    name="aux",
    version="0.0.1",
    author="ABL",
    author_email="abl@example.com",
    description="Bits and bobs to help",
    packages=find_packages(),
)